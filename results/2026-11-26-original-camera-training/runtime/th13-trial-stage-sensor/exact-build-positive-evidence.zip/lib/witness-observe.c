/* Read-only telemetry for the unmodified official TH13 Trial 0.01a executable.
   Build verified by the launcher. Counters were calibrated against native input, HUD inventory, and the pause menu. */
#include <windows.h>
#include <tlhelp32.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

static int get(HANDLE process, uintptr_t at, void *dest, size_t length) {
    SIZE_T n = 0;
    return ReadProcessMemory(process, (const void *)at, dest, length, &n) && n == length;
}
static int32_t scalar(HANDLE p, uintptr_t at) {
    int32_t v = -999;
    get(p, at, &v, sizeof(v));
    return v;
}
static int write_player_label(FILE *file,HANDLE process,uintptr_t base,const int32_t *state) {
    uint32_t player=0;
    float position[2], bounds[6];
    if (!get(process,base+0xbcb20,&player,sizeof(player)) || player<65536 ||
        !get(process,player+0x550,position,sizeof(position)) ||
        !get(process,player+0x5a0,bounds,sizeof(bounds))) return 1;
    int32_t row[15]={0};
    row[0]=state[0]; row[1]=(int32_t)GetTickCount(); row[2]=state[11];
    row[3]=state[3]; row[4]=state[4]; row[5]=state[5];
    memcpy(row+6,position,sizeof(position));
    memcpy(row+8,bounds,2*sizeof(float)); memcpy(row+10,bounds+3,2*sizeof(float));
    row[12]=state[10]; row[13]=state[2]; row[14]=state[0];
    rewind(file);
    return fwrite(row,sizeof(row),1,file)==1 && !fflush(file);
}
static DWORD pid_of_game(void) {
    PROCESSENTRY32 proc = {0}; proc.dwSize=sizeof(proc);
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    DWORD pid=0;
    if (Process32First(snapshot,&proc)) do {
        if (!_stricmp(proc.szExeFile,"th13.exe")) {
            if (pid) { pid=0; break; }
            pid=proc.th32ProcessID;
        }
    } while (Process32Next(snapshot,&proc));
    CloseHandle(snapshot);
    return pid;
}

int main(void){
 DWORD pid=pid_of_game();if(!pid)return 1;MODULEENTRY32 e={0};e.dwSize=sizeof(e);
 HANDLE ss=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);if(!Module32First(ss,&e))return 2;CloseHandle(ss);
 uintptr_t b=(uintptr_t)e.modBaseAddr;HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,pid);
 FILE *latest=fopen("Z:/capture/probe.bin","wb+"),*history=fopen("Z:/capture/probe-history.bin","wb");if(!latest||!history)return 3;
 int oldtick=-1;
 for(int sequence=1;sequence<300000;sequence++){
  int32_t rec[53]={0},stock[34],candidates[30];uint32_t player=0;
  if(!get(p,b+0xb9048,stock,sizeof(stock)))break;
  rec[0]=sequence;rec[1]=scalar(p,b+0xd7464);rec[2]=scalar(p,b+0xd9960);
  rec[3]=stock[24];rec[4]=stock[14];rec[5]=stock[17];rec[6]=stock[27];rec[7]=stock[3];rec[8]=stock[26];
  get(p,b+0xbcb20,&player,sizeof(player));rec[9]=player?1:0;
  if(player>65536){get(p,player+0x550,rec+10,8);get(p,player+0x5c0,rec+12,30*4);}
  for(int i=0;i<10;i++)rec[42+i]=stock[21+i];
  rec[52]=sequence;rewind(latest);fwrite(rec,sizeof(rec),1,latest);fflush(latest);
  if(rec[6]!=oldtick){fwrite(rec,sizeof(rec),1,history);oldtick=rec[6];if(!(oldtick%60))fflush(history);}
  Sleep(4);
 }
 fclose(latest);fclose(history);CloseHandle(p);return 0;
}