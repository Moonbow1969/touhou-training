#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
typedef struct _XDisplay Display;
extern Display *XOpenDisplay(const char *);
extern unsigned char XKeysymToKeycode(Display *,unsigned long);
extern int XTestFakeKeyEvent(Display *,unsigned int,int,unsigned long);
extern int XSync(Display *,int);
int main(void){
 Display *d=XOpenDisplay(NULL);if(!d)return 10;
 int bits[8]={64,128,16,32,8,1,2,4};unsigned long matches[8]={0xff51,0xff53,0xff52,0xff54,0xffe1,'z','x','c'};
 unsigned char keys[8];for(int i=0;i<8;i++)keys[i]=XKeysymToKeycode(d,matches[i]);
 FILE *f=fopen("/capture/lib/human-input.bin","rb"),*log=fopen("/capture/controller.csv","w");if(!f||!log)return 9;
 uint16_t source[40000];int n=fread(source,2,40000,f);fclose(f);
 fprintf(log,"wall_ms,stage,tick,spares,bombs,chapter,screen,pause,playerstate,dbtimer,word,xy_x,xy_y\n");
 int fd=open("/capture/probe.bin",O_RDONLY),old=0,previous=-1,event=0,last=-900,active=0,scan=0,finish=0,oldstage=0;
 struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);long long begin=ts.tv_sec*1000LL+ts.tv_nsec/1000000;
 while(!finish){
  int32_t s[53];if(pread(fd,s,sizeof(s),0)!=sizeof(s)||s[0]<=0||s[0]!=s[52]){usleep(2000);continue;}
  clock_gettime(CLOCK_MONOTONIC,&ts);long long elapsed=ts.tv_sec*1000LL+ts.tv_nsec/1000000-begin;
  int tick=s[6],stage=s[3],pstate=s[25],db=s[28],next=0;
  int changed=tick!=previous||stage!=oldstage;
  if(s[1]==7 && s[2]==2 && s[9]){
   active=1;
   if(changed){
     if(tick<previous-100||stage!=oldstage){event=0;last=-900;}
     if(stage==1){
       next=(tick>0&&tick-1<n)?source[tick-1]&0xf8:0;
       if(tick>=n)next|=(tick/115)%2?64:128;
     }
     if(tick%16!=0)next|=1;
     if(pstate==4 && tick-last>12){
       event=s[5]>0?2:4;last=tick;
     }
     if(tick-last>=0 && tick-last<3)next|=event;
     if(stage>=2 && tick>=500)finish=1;
   }else next=old;
  }else if(active && (s[2]==1||s[4]<0)){finish=1;}
  if(elapsed>700000)finish=1;
  if(next!=old){for(int i=0;i<8;i++)if((next^old)&bits[i])XTestFakeKeyEvent(d,keys[i],(next&bits[i])!=0,0);XSync(d,0);}
  if(changed||next!=old||scan++%100==0){
   float x,y;__builtin_memcpy(&x,s+10,4);__builtin_memcpy(&y,s+11,4);
   fprintf(log,"%lld,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.2f,%.2f\n",elapsed,stage,tick,s[4],s[5],s[8],s[1],s[2],pstate,db,next,x,y);
   if(tick%60==0||finish)fflush(log);
  }
  old=next;previous=tick;oldstage=stage;usleep(2500);
 }
 for(int i=0;i<8;i++)if(old&bits[i])XTestFakeKeyEvent(d,keys[i],0,0);XSync(d,0);fclose(log);return 0;
}
