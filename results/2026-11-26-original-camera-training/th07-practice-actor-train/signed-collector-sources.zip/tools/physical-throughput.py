from pathlib import Path
import json,csv,hashlib,os
r=Path('outputs/touhou-vision-261126/th07-practice-actor-train')
stats=[]
for c in (r/'raw').glob('*/qualification.json'):
 f=c.parent
 trace=list(csv.DictReader((f/'controls.csv').open()))
 if not trace:continue
 first,last=int(trace[0]['camera_ns']),int(trace[-1]['camera_ns'])
 obs=next(csv.DictReader((f/'observer-distribution.csv').open()))
 finish=json.loads((f/'finished-game.json').read_bytes())
 stats.append(dict(seed=finish['seed'],lane=finish['lane'],decision_ns=[first,last],decisions=len(trace),ticks_per_s_excluding_first_and_last_boundary=(int(trace[-1]['tick'])-int(trace[0]['tick']))/((last-first)*1e-9),native_read_p999_ms=float(obs['p999_upper_ns'])/1e6,native_read_max_ms=float(obs['max_ns'])/1e6,qualified_source_bytes=sum(p.stat().st_size for p in f.iterdir() if p.is_file())))
overlaps=[]
for i,a in enumerate(stats):
 for b in stats[i+1:]:
  if a['lane']==b['lane']:continue
  lo=max(a['decision_ns'][0],b['decision_ns'][0]);hi=min(a['decision_ns'][1],b['decision_ns'][1])
  if hi>lo:overlaps.append(dict(seeds=[a['seed'],b['seed']],concurrent_action_seconds=(hi-lo)*1e-9))
output=dict(rows=sorted(stats,key=lambda a:a['seed']),overlapping_gameplay=overlaps,source='CLOCK_MONOTONIC inside the same Gamer WSL kernel for both containers. Endpoints exclude the subsequent cutoff/terminal frame.',root_free_bytes_at_sample=__import__('shutil').disk_usage(r).free)
tmp=r/'physical-throughput.pending';tmp.write_text(json.dumps(output,indent=2)+'\n');tmp.replace(r/'physical-throughput.json')
print(len(stats),len(overlaps))
