from pathlib import Path
import json,csv,statistics
from collections import Counter
d=Path('outputs/touhou-vision-261126/th07-practice-actor-train');src=d/'raw'
idx=Path('work/th07-fragment-intake-261128/practice')
report=json.loads((idx/'intake-index.json').read_bytes())
if not report['complete']:raise ValueError('Wait for independent final receipts')
rows=[]
for audit in report['rows']:
 s=audit['seed'];f=src/str(s);ad=json.loads((idx/audit['receipt']).read_bytes())
 e=json.loads((f/'finished-game.json').read_bytes());q=json.loads((f/'qualification.json').read_bytes())
 n=list(csv.DictReader((f/'native-input.csv').open()));last=n[-1]
 rows.append(dict(seed=s,scene=audit['scene'],lane=e['lane'],qualified=audit['qualified'],decisions=e['actions'],native_ticks=ad['native_elapsed_ticks'],outcome=audit['outcome'],first_stock=ad['first_stock'],end_stock=ad['end_stock'],terminal_stage=int(last['stage']),last_tick=int(last['tick']),misses=int(last['misses']),spent=int(last['bombs_used']),exact=ad['exact_native_windows'],compared=ad['original_windows'],consumed=ad['action_masks_with_native_consumption']))
out=dict(total_originals=len(rows),setup_failures_zero_action=1,eligible_originals=sum(r['qualified'] for r in rows),decisions=sum(r['decisions'] for r in rows),eligible_decisions=sum(r['decisions'] for r in rows if r['qualified']),consumed=sum(r['consumed'] for r in rows),exact=sum(r['exact'] for r in rows),compared=sum(r['compared'] for r in rows),outcomes=dict(Counter(r['outcome'] for r in rows)),scenes={})
for scene in sorted({r['scene'] for r in rows}):
 rr=[r for r in rows if r['scene']==scene]
 out['scenes'][scene]=dict(real=len(rr),eligible=sum(r['qualified'] for r in rr),outcomes=dict(Counter(r['outcome'] for r in rr)),median_ticks=statistics.median(r['native_ticks'] for r in rr),known_misses=sum(r['misses'] for r in rr),bombs_used_counter_sum=sum(r['spent'] for r in rr))
out['rows']=rows
(d/'original-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
