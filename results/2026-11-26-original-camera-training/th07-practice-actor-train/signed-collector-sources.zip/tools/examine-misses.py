import csv,json,numpy as np
from pathlib import Path
d=Path('outputs/touhou-vision-261126/th07-practice-actor-train')
idx=Path('work/th07-fragment-intake-261128/practice')
acc=[]
for fi in sorted(idx.glob('2174*.json')):
 a=json.loads(fi.read_bytes());s=a['seed'];l=a.get('nonexact_action_indices',[])
 if not l:continue
 p=d/'raw'/str(s)
 c=list(csv.DictReader((p/'applied.csv').open()));n=list(csv.DictReader((p/'native-input.csv').open()))
 w={int(r['tick']):int(r['record_slot']) for r in n}
 for r in n:w[int(r['tick'])-1]=int(r['previous_slot'])
 for f in ('record-stage1.bin','practice-record-prefix.bin'):
  if (p/f).is_file():
   buf=np.frombuffer((p/f).read_bytes(),'<u2',offset=44)[::2];w.update(enumerate(buf.tolist()))
 for i in l:
  start=int(c[i]['camera_tick']);end=int(c[i+1]['camera_tick']) if i+1<len(c) else int(n[-1]['tick']);target=start+4
  native_hits=[r for r in n if int(r['tick']) in (target-1,target,target+1)];event_times=[(int(r['tick']),int(r['ns'])) for r in native_hits]
  print(s,i,start,end,'effective', [w.get(j) for j in range(start+1,end+1)],'brackets',event_times)
  acc.append(dict(seed=s,decision_index=i,camera_tick=start,following_boundary=end,requested=int(c[i]['requested_word']),native_words=[w.get(j) for j in range(start+1,end+1)],target_tick_seen_in_realtime=any(r[0]==target for r in event_times),adjacent_candidate_ns=event_times))
(d/'native-timing-exceptions.json').write_text(json.dumps(acc,indent=2)+'\n')
