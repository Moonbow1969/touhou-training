from pathlib import Path
from statistics import median
import csv,json
d=Path('outputs/touhou-vision-261126/th07-practice-actor-train')
events={}
for path in d.glob('dispatch*.ndjson'):
 for line in path.read_text().splitlines():
  r=json.loads(line);events.setdefault((r['seed'],r['event']),r['time'])
rows=[]
for source in sorted((d/'raw').iterdir()):
 if not source.is_dir():continue
 seed=int(source.name)
 def mtime(f):return (source/f).stat().st_mtime
 def native(which):
    with (source/which).open() as h: return list(csv.DictReader(h))
 markers={'dispatch':events.get((seed,'launch')),'wine_thprac_ready':mtime('ready'),'title_highlighted':mtime('practice-start.png'),
          'practice_overlay':mtime('fresh-practice-overlay.png'),'scenario_selected':mtime('configured-practice.png'),
          'learned_worker_ready':mtime('worker-ready'),'menu_keys_released':mtime('menu-released'),'behavior_sealed':mtime('finished-game.json'),
          'source_checked':mtime('qualification.json'),'docker_cleanup_complete':events.get((seed,'sealed'))}
 keys=list(markers);segments={}
 for k1,k2 in zip(keys,keys[1:]):
  if markers[k1] is not None and markers[k2] is not None:segments[k1+'__'+k2]=round(markers[k2]-markers[k1],3)
 controls=native('controls.csv');native_rows=native('native-input.csv')
 segments['first_to_last_actor_camera']=round((int(controls[-1]['camera_ns'])-int(controls[0]['camera_ns']))/1e9,3)
 segments['original_ticks_per_second']=round((int(controls[-1]['tick'])-int(controls[0]['tick']))/segments['first_to_last_actor_camera'],3)
 segments['dispatch_to_original_menu_release']=round(markers['menu_keys_released']-markers['dispatch'],3)
 rows.append(dict(seed=seed,segments_seconds=segments,stock_native_read_samples=len(native_rows)))
keys={k for r in rows for k in r['segments_seconds']}
stats={k:dict(observed=sum(k in r['segments_seconds'] for r in rows),median=median(r['segments_seconds'][k] for r in rows if k in r['segments_seconds'])) for k in sorted(keys)}
output=dict(started_originals=len(rows),timestamp_definition='Windows dispatch wall clock and original source file mtimes on the same host. Adjacent stages include all intervening work and scheduling. Native camera interval and original ticks per second use the Linux native monotonic clock. Initial 3 setup receipts used legacy dispatchers; some teardown markers are missing, preserved as absent.',median_segments=stats,rows=rows)
(d/'reset-timing-breakdown.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(stats))
